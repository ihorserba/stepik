#!/bin/bash

python manage.py run-tests

python manage.py run-tests --esv=2

python manage.py run-tests --esv=5

python manage.py run-tests --esv=6

python manage.py run-tests --esv=7