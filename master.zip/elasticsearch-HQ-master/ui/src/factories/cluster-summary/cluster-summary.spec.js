
// Stubbed test.
describe('cluster-summary Factory', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
