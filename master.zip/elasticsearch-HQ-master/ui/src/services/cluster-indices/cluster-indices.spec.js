
// Stubbed test.
describe('cluster-indices Service', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
