
// Stubbed test.
describe('cluster-aliases Service', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
