import './index-shards-tab-content.style.scss'

class indexShardsTabContentController {

}

export default indexShardsTabContentController;
