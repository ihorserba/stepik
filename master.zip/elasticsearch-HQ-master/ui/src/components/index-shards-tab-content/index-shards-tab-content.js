import angular from 'angular';
import indexShardsTabContent from './index-shards-tab-content.component';

export default angular.module('eshq.indexShardsTabContent', [])
  .component('eshqIndexShardsTabContent', indexShardsTabContent)
  .name;
