
// Stubbed test.
describe('footer Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
