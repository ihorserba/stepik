import angular from 'angular';
import footer from './footer.component';

export default angular.module('eshq.footer', [])
  .component('eshqFooter', footer)
  .name;
