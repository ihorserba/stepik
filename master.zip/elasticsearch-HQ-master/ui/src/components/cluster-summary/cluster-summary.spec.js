
// Stubbed test.
describe('cluster-summary Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
