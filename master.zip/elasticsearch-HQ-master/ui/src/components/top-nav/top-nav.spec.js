
// Stubbed test.
describe('top-nav Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
