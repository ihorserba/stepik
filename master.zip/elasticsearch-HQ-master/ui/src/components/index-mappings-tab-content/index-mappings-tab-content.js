import angular from 'angular';
import indexMappingsTabContent from './index-mappings-tab-content.component';

export default angular.module('eshq.indexMappingsTabContent', [])
  .component('eshqIndexMappingsTabContent', indexMappingsTabContent)
  .name;
