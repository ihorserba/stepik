import './index-metric-querycache.style.scss'

class indexMetricQuerycacheController {

}

export default indexMetricQuerycacheController;
