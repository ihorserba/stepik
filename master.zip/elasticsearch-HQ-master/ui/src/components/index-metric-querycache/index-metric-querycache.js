import angular from 'angular';
import indexMetricQuerycache from './index-metric-querycache.component';

export default angular.module('eshq.indexMetricQuerycache', [])
  .component('eshqIndexMetricQuerycache', indexMetricQuerycache)
  .name;
