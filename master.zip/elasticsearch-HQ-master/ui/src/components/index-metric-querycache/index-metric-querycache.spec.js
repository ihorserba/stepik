
// Stubbed test.
describe('index-metric-querycache Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
