import './node-summary-info-table.style.scss'

class nodeSummaryInfoTableController {

}

export default nodeSummaryInfoTableController;
