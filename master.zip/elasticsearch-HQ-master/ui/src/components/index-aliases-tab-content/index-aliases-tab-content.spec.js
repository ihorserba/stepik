
// Stubbed test.
describe('index-aliases-tab-content Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
