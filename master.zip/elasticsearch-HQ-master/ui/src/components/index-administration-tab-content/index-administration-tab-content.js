import angular from 'angular';
import indexAdministrationTabContent from './index-administration-tab-content.component';

export default angular.module('eshq.indexAdministrationTabContent', [])
  .component('eshqIndexAdministrationTabContent', indexAdministrationTabContent)
  .name;
