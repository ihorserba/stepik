import './index-administration-tab-content.style.scss'

class indexAdministrationTabContentController {

}

export default indexAdministrationTabContentController;
