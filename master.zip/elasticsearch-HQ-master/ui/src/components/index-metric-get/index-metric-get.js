import angular from 'angular';
import indexMetricGet from './index-metric-get.component';

export default angular.module('eshq.indexMetricGet', [])
  .component('eshqIndexMetricGet', indexMetricGet)
  .name;
