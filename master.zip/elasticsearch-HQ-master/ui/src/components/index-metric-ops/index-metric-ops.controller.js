import './index-metric-ops.style.scss'

class indexMetricOpsController {

}

export default indexMetricOpsController;
