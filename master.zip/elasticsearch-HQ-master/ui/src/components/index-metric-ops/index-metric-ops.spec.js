
// Stubbed test.
describe('index-metric-ops Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
