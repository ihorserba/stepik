import './node-jvm-stats-table.style.scss'

class nodeJvmStatsTableController {

}

export default nodeJvmStatsTableController;
