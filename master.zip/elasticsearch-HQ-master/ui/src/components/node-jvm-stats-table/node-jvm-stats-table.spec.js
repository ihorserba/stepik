
// Stubbed test.
describe('node-jvm-stats-table Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
