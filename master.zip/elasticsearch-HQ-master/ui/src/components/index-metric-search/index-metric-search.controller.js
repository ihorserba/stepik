import './index-metric-search.style.scss'

class indexMetricSearchController {

}

export default indexMetricSearchController;
