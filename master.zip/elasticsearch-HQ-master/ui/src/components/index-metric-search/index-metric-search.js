import angular from 'angular';
import indexMetricSearch from './index-metric-search.component';

export default angular.module('eshq.indexMetricSearch', [])
  .component('eshqIndexMetricSearch', indexMetricSearch)
  .name;
