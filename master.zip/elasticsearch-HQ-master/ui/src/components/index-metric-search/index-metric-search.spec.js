
// Stubbed test.
describe('index-metric-search Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
