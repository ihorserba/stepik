
// Stubbed test.
describe('node-diagnostics-wrapper Component', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
