
// Stubbed test.
describe('cluster-indices Container', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
