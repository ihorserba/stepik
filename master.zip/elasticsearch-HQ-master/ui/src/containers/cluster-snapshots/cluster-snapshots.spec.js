
// Stubbed test.
describe('cluster-snapshots Container', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
