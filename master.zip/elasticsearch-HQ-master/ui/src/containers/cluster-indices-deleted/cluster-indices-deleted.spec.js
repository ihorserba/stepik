
// Stubbed test.
describe('cluster-indices-deleted Container', () => {
  it('base test', () => {
    expect(1).toEqual(1);
  });
});
