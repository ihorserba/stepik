The Legal Stuff
===============

By using ElasticHQ, you agree to everything on this page. We have to do this to protect both you and us and make running this FREE software service possible. If you break these terms, you can't use ElasticHQ anymore.

So here it is, in plain english...
----------------------------------

1. We are not liable for misuse of ElasticHQ, or for it not meeting your needs.
2. We are not liable for any harm you bring to your data, software, or hardware by using ElasticHQ.  
